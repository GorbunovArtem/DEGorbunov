<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Auth;

class MainController extends Controller
{
    public function registration(){
        return view('registration');
    }

    public function authorization(){
        return view('authorization');
    }
    
    public function requests(){
        return view('requests');
    }

    public function addRequests(){
        return view('addRequests');
    }

    public function admin(){
        return view('admin');
    }

    public function reg(Request $request){
        // dd($request->all());
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'number' => $request->number,
            'login' => $request->login,
            'password' => $request->password,
        ]);

        Auth::login($user);

        return redirect(RouteServiceProvider::HOME);
    }


}
