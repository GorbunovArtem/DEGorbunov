@include('layouts.header')

    <div class="container">
        <h1>Новое Заявление</h1>
        <hr>
        <form action="/addReq" method="POST">
            @csrf
            <input type="text" placeholder="Номер авто" name="numberAuto" required><br>
            <input type="text" placeholder="Описание нарушения" name="description" required><br>
            <input type="text" name="id_user" readonly hidden><br>
            <button type="submit">Отправить</button>
        </form>
    </div>

@include('layouts.footer')