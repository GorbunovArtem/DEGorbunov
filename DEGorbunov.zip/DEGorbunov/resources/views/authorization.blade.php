@include('layouts.header')

    <div class="container">
        <h1>Авторизация</h1>
        <hr>
        <form action="/auth" method="POST">
            @csrf
            <input type="text" placeholder="Логин" name="login" required><br>
            <input type="password" placeholder="password" name="password" required><br>
            <button type="submit">Вход</button>
        </form>
    </div>

@include('layouts.footer')