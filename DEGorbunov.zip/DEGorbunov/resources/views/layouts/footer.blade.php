<footer>
    <div class="nav_container">
        <nav class="flex">
            <a href="/">Регистрация</a>
            <a href="/authorization">Вход</a>
            <a href="/requests">Заявления</a>
            <a href="/addRequest">Новое Заявление</a>
            <a href="/admin">Админ</a>
        </nav>
    </div>
</footer>
</body>
</html>