<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>Нарушениям.Нет</title>
</head>
<body>
    <header>
        <div class="nav_container">
            <nav class="flex">
                <a href="/" class="logo"><b>Нарушениям.нет</b></a>
                <a href="/">Регистрация</a>
                <a href="/authorization">Вход</a>
                <a href="/requests">Заявления</a>
                <a href="/addRequest">Новое Заявление</a>
                <a href="/admin">Админ</a>
            </nav>
        </div>
    </header>