@include('layouts.header')

    <div class="container">
        <h1>Регистрация</h1>
        <hr>
        <form action="/reg" method="POST">
            @csrf
            <input type="text" placeholder="ФИО" name="name" required><br>
            <input type="email" placeholder="Email" name="email" required><br>
            <input type="text" placeholder="Телефон: 89086200252" name="number" required><br>
            <input type="text" placeholder="Логин" name="login" required><br>
            <input type="password" placeholder="password" name="password" required><br>
            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>

@include('layouts.footer')