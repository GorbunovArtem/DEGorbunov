@include('layouts.header')

    <div class="container">
        <h1>Ваши Заявления</h1>
        <hr>
        <table cellspacing='0'>
            <tr>
                <td><b>Номер заявления</b></td>
                <td><b>Номер автомобиля</b></td>
                <td><b>Описание нарушения</b></td>
                <td><b>Статус</b></td>
            </tr>
            <tr>
                <td>325</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Новое</td>
            </tr>
            <tr>
                <td>325</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Новое</td>
            </tr>
            <tr>
                <td>325</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Новое</td>
            </tr>
            <tr>
                <td>325</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Новое</td>
            </tr>
        </table>
    </div>

@include('layouts.footer')