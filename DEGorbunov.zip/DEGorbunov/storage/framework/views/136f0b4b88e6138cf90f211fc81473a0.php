<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <h1>Заявления</h1>
        <hr>
        <table cellspacing='0'>
            <tr style="text-align: center;">
                <td><b>ФИО подавшего</b></td>
                <td><b>Номер автомобиля</b></td>
                <td><b>Описание нарушения</b></td>
                <td><b>Статус</b></td>
                <td colspan="2"><b>Изменение статуса</b></td>
            </tr>
            <tr>
                <td>Иванов Иван Иванович</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Новое</td>
                <td><b><a href="/confirm/325">Подтвердить</a></b></td>
                <td><b><a href="/rejected/325">Подтвердить</a></b></td>
            </tr>
            <tr>
                <td>Иванов Иван Иванович</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Подтверждено</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td>Иванов Иван Иванович</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Отклонено</td>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td>Иванов Иван Иванович</td>
                <td>c123ph96</td>
                <td>Проезд на красный свет</td>
                <td>Новое</td>
                <td><b><a href="/confirm/325">Подтвердить</a></b></td>
                <td><b><a href="/rejected/325">Подтвердить</a></b></td>
            </tr>
        </table>
    </div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\DEGorbunov\resources\views/admin.blade.php ENDPATH**/ ?>