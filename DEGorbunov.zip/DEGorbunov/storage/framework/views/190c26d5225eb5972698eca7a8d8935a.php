<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <h1>Авторизация</h1>
        <hr>
        <form action="/auth" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" placeholder="Логин" name="login" required><br>
            <input type="password" placeholder="password" name="password" required><br>
            <button type="submit">Вход</button>
        </form>
    </div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\DEGorbunov\resources\views/authorization.blade.php ENDPATH**/ ?>