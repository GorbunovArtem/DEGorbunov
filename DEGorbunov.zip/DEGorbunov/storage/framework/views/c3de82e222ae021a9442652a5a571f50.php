<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <h1>Регистрация</h1>
        <hr>
        <form action="/reg" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" placeholder="ФИО" name="name" required><br>
            <input type="email" placeholder="Email" name="email" required><br>
            <input type="text" placeholder="Телефон: 89086200252" name="number" required><br>
            <input type="text" placeholder="Логин" name="login" required><br>
            <input type="password" placeholder="password" name="password" required><br>
            <button type="submit">Зарегистрироваться</button>
        </form>
    </div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\DEGorbunov\resources\views/registration.blade.php ENDPATH**/ ?>